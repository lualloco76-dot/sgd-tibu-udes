#requires -Version 5.1
# Subida segura al repositorio de GitHub ya creado. No requiere reescribir la historia.
$ErrorActionPreference = 'Stop'
$repo = 'lualloco76-dot/sgd-tibu-udes'
$source = Join-Path $PSScriptRoot 'CODIGO_SGD_TIBU'
Write-Host "Subida de SGD Tibu UDES a $repo" -ForegroundColor Cyan
if (-not (Test-Path -LiteralPath $source)) { throw 'Falta CODIGO_SGD_TIBU: extrae primero todo el ZIP.' }
foreach ($cmd in @('git','gh')) {
  if (-not (Get-Command $cmd -ErrorAction SilentlyContinue)) {
    throw "Falta $cmd. Instala Git para Windows (git-scm.com) y GitHub CLI (cli.github.com)."
  }
}
& gh auth status
if ($LASTEXITCODE -ne 0) { throw 'Debes iniciar sesion con: gh auth login' }
$login = (& gh api user --jq '.login').Trim()
if ($LASTEXITCODE -ne 0 -or $login -ne 'lualloco76-dot') {
  throw "Cuenta no esperada ($login). Inicia sesion en GitHub con lualloco76-dot."
}
$visibility = (& gh repo view $repo --json visibility -q '.visibility').Trim()
if ($LASTEXITCODE -ne 0) { throw 'No puedo ver el repositorio. Comprueba que existe y que tienes permisos.' }
if ($visibility -ne 'PRIVATE') {
  throw 'SEGURIDAD: el repositorio sigue PUBLIC. Cambialo a PRIVATE en GitHub Settings > General > Danger Zone > Change repository visibility, y vuelve a ejecutar el script.'
}
& gh auth setup-git
if ($LASTEXITCODE -ne 0) { throw 'No fue posible configurar Git con GitHub CLI.' }
$temp = Join-Path $env:TEMP ('sgd-tibu-publicar-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $temp | Out-Null
$dest = Join-Path $temp 'sgd-tibu-udes'
& git clone "https://github.com/$repo.git" $dest
if ($LASTEXITCODE -ne 0) { throw 'No fue posible clonar el repositorio actual.' }
# Reemplaza README inicial y copia contenido del proyecto (nunca copia una carpeta .git).
Get-ChildItem -LiteralPath $source -Force | ForEach-Object {
  if ($_.Name -ne '.git') {
    Copy-Item -LiteralPath $_.FullName -Destination $dest -Force -Recurse
  }
}
& git -C $dest add --all
if ($LASTEXITCODE -ne 0) { throw 'Error preparando los cambios de Git.' }
$changes = (& git -C $dest status --porcelain)
if (-not $changes) {
  Write-Host 'El repositorio ya contiene estos archivos. Sin cambios nuevos.' -ForegroundColor Green
  Write-Host "https://github.com/$repo"
  exit 0
}
$gitName = (& git -C $dest config user.name)
if (-not $gitName) { & git -C $dest config user.name 'lualloco76-dot' }
$gitEmail = (& git -C $dest config user.email)
if (-not $gitEmail) {
  $userId = (& gh api user --jq '.id').Trim()
  & git -C $dest config user.email "$userId+lualloco76-dot@users.noreply.github.com"
}
& git -C $dest commit -m 'Incorporar codigo y pruebas SGD Tibu UDES v3.1.0'
if ($LASTEXITCODE -ne 0) { throw 'No se pudo crear el commit.' }
& git -C $dest push origin HEAD:main
if ($LASTEXITCODE -ne 0) { throw 'No se pudo subir la version a GitHub.' }
Write-Host "PUBLICACION COMPLETADA: https://github.com/$repo" -ForegroundColor Green
Write-Host 'Verifica las carpetas backend, frontend, database y documentacion antes de compartir con la docente.'
